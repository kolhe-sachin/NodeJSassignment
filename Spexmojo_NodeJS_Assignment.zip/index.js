const express = require('express')
const app = express();
require('./src/db/mongoose');


const userRouter = require('./src/router/userRouter');
const adminRouter = require('./src/router/adminRouter');

const router = new express.Router();

app.use(express.json());
app.use(userRouter);
app.use(adminRouter);


app.listen(8080, () => {
    console.log('Server is up and running!');
})