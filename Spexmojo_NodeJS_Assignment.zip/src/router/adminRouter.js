const express = require("express");
const mongoose = require('mongoose');

const router = new express.Router();
const Admin = require('../models/admin');
const User = require('../models/user');

router.post('/admin', (req, res) => {
    const admin = new Admin(req.body)
    admin.save().then((data) => {
        res.status(201).send(data);
    }).catch((e) => {
        res.status(401).send(e)
    })
})

// router.get('/admin/getAllData', (req, res) => {
//     User.find({}).then((user) => {
//         Admin.find({}).then((admin) => {
//             res.send([user, admin])
//         })
//     }).catch((e) => {
//         res.status(400).send();
//     })
// })
router.get('/admin/getAllData/:id', (req, res) => {
    const _id = req.params.id;
    Admin.findById(_id).then((user) => {
        if (!user) {
            return res.status(401).send('Invalid user')
        }
        User.find({}).then((user) => {
            Admin.find({}).then((admin) => {
                res.send([user, admin])
            })

        }).catch((e) => {
            res.status(400).send(e);
        })
    })
})

module.exports = router;