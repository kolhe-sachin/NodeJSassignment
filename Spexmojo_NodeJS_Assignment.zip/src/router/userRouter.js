const express = require("express");
const mongoose = require('mongoose');

const router = new express.Router();
const User = require('../models/user');
const areUsersNear = require('../nearByUsers');

router.post('/users', (req, res) => {
    const user = new User(req.body);
    user.save().then((data) => {
        res.status(201).send(data)
    }).catch((e) => {
        res.status(400).send(e)
    })
})

router.get('/users/nearbyUsers/:id', (req, res) => {
    const _id = req.params.id;
    User.findById(_id).then((user) => {
        if(!user) {
            return res.status(404).send('Invalid Users')
        }
        User.find({}).then((records) => {
            const co1 = user.location;
            const nearestUser = []
            for (let i = 1; i < records.length; i++) {
                const x = records[i].location
                const temp = co1;
                if (areUsersNear(co1, x, 5)) {
                    nearestUser.push(records[i].name);
                }
            }
            res.status(200).send({ProfileInfo:user,nearestUser});
        })
    }).catch((e) => {
        res.status(500).send('Invalid user')
    })
})

module.exports = router