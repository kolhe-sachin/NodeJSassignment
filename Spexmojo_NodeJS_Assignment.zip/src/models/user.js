const mongoose = require('mongoose');
const validator = require('validator');

const User = mongoose.model('User', {
    name: {
        type: String,
        required: true,
    },
    mobile: {
        type: String,
        required: true,
        unique: true,
        validate(value){
            if(!validator.isMobilePhone(value,'en-IN')){
                throw new Error('Mobile number is invalid!')
            }
        }
    
    },
    role: {
        type: String,
        required: true,
        validate(value) {
            if (!(value === 'User' || value === 'user')) {
                throw new Error('Invalid user!')
            }
        }
    },
    location: {
        type: Object,
        required: true
    }
})

module.exports = User



// module.exports = User;