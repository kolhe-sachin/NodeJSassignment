const mongoose = require('mongoose');
const validator = require('validator');

const Admin = mongoose.model('Admin', {
    name: {
        type: String,
        required: true,
    },
    mobile: {
        type: String,
        required: true,
        unique: true,
        validate(value) {
            if (!validator.isMobilePhone(value, 'en-IN')) {
                throw new Error('Mobile number is invalid!')
            }
        }
    },
    role: {
        type: String,
        required: true,
        validate(value) {
            if (!(value === 'Admin' || value === 'admin')) {
                throw new Error('Invalid User!')
            }
        }
    },
    location: {
        type: Object,
        required: true,
    }
})

module.exports = Admin;
